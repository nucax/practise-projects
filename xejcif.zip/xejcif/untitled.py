import tkinter as tk
from tkinter import messagebox
import pygame

# Initialize pygame mixer
pygame.mixer.init()

# Load and play the music
pygame.mixer.music.load("fun.mp3")  # Make sure fun.mp3 is in the same folder
pygame.mixer.music.play(loops=-1)   # -1 = loop forever

# Warning popup
def show_warning():
    warning_message = (
        "WARNING\n\n"
        "This game is intended for players 18 years or older.\n"
        "It contains graphic content including blood, gore, death, self-harm, suicide, and drug use.\n"
        "If you are struggling with mental health, playing this game may make it worse.\n"
        "Player discretion is strongly advised."
    )
    messagebox.showwarning("warning..", warning_message)
    open_main_menu()

# Main menu
def open_main_menu():
    root = tk.Tk()
    root.title("Untitled Game")
    root.configure(bg="black")
    root.attributes("-fullscreen", True)

    # Frames
    menu_frame = tk.Frame(root, bg="black")
    ascii_frame = tk.Frame(root, bg="black")

    # ASCII art
    ascii_art = '''
       .-""""-.
     .'        '.
    /            \\
   |,  .-.  .-.  ,|
   | )(_o/  \\o_)( |
   |/     /\\     \\|
   (_     ^^     _)
    \\__|IIIIII|__/
     | \\IIIIII/ |
     \\          /
      `--------`
    '''
    ascii_label = tk.Label(ascii_frame, text=ascii_art, fg="white", bg="black", justify="left")
    ascii_label.pack(expand=True)

    # Menu content
    title_label = tk.Label(menu_frame, text="UNTITLED GAME :(", fg="grey", bg="black", anchor="w")
    title_label.pack(pady=(0,50), anchor="w")

    buttons = []
    start_btn = tk.Button(menu_frame, text="Start Game", bg="grey", fg="black", command=lambda: print("Game Started"))
    start_btn.pack(pady=10, anchor="w")
    buttons.append(start_btn)

    exit_btn = tk.Button(menu_frame, text="Exit", bg="grey", fg="black", command=root.destroy)
    exit_btn.pack(pady=10, anchor="w")
    buttons.append(exit_btn)

    # Layout update
    def update_layout(event=None):
        width = root.winfo_width()
        height = root.winfo_height()
        menu_frame.pack(side="left", fill="both", expand=True, padx=50, pady=50)
        ascii_frame.pack(side="right", fill="both", expand=True, padx=50, pady=50)
        title_label.config(font=("Courier", max(16, int(height * 0.07))))
        for btn in buttons:
            btn.config(font=("Arial", max(10, int(height * 0.03))))
        ascii_label.config(font=("Courier", max(8, int(height * 0.02))))

    root.bind("<Configure>", update_layout)
    update_layout()
    root.mainloop()

# Run
root = tk.Tk()
root.withdraw()
show_warning()