#include <windows.h>
#include <mmsystem.h>
#include <endpointvolume.h>
#include <mmdeviceapi.h>
#pragma comment(lib, "winmm.lib")

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmdLine, int nCmdShow)
{
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    POINT center = { screenWidth / 2, screenHeight / 2 };

    PlaySound(TEXT("fun.mp3"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);

    CoInitialize(NULL);
    IMMDeviceEnumerator* pEnum = NULL;
    IMMDevice* pDevice = NULL;
    IAudioEndpointVolume* pVolume = NULL;
    CoCreateInstance(__uuidof(MMDeviceEnumerator), NULL, CLSCTX_ALL, IID_PPV_ARGS(&pEnum));
    pEnum->GetDefaultAudioEndpoint(eRender, eConsole, &pDevice);
    pDevice->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_ALL, NULL, (void**)&pVolume);

    DWORD lastVolumeSet = GetTickCount();

    while (true)
    {
        SetCursorPos(center.x, center.y);
        if (GetTickCount() - lastVolumeSet >= 3000)
        {
            pVolume->SetMasterVolumeLevelScalar(1.0f, NULL);
            lastVolumeSet = GetTickCount();
        }
        Sleep(10);
    }

    pVolume->Release();
    pDevice->Release();
    pEnum->Release();
    CoUninitialize();
    return 0;
}
